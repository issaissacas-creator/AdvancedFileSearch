package com.example.advancedfilesearch

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.text.DecimalFormat
import java.util.Locale
import kotlin.concurrent.thread

data class FileItem(val displayName: String, val path: String, val score: Int, val file: File? = null, val document: DocumentFile? = null)

class MainActivity : AppCompatActivity() {

    private lateinit var searchBox: EditText
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var progress: ProgressBar
    private val index = ArrayList<FileItem>()
    private val decimal = DecimalFormat("#,###")
    private val permissionRequest = 700
    private val sdPrefs = "storage"
    private val sdUriKey = "sd_uri"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (hasStoragePermission()) {
            indexFiles()
        } else {
            requestStoragePermission()
        }
    }

    private fun hasStoragePermission(): Boolean {
        return android.os.Build.VERSION.SDK_INT < 23 ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestStoragePermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                permissionRequest
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (hasStoragePermission()) indexFiles()
            else status.text = "يجب السماح بالوصول إلى الملفات حتى يعمل البحث."
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 16)
            layoutDirection = ViewGroup.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "البحث المتقدم عن الملفات"
            textSize = 24f
            gravity = Gravity.RIGHT
        }
        root.addView(title)

        val help = TextView(this).apply {
            text = "ابحث بأي أجزاء من الاسم، حتى لو كانت الكلمات غير مرتبة."
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(help)

        searchBox = EditText(this).apply {
            hint = "مثال: ازن مدر أو رس هب"
            singleLine = true
            textSize = 18f
        }
        root.addView(searchBox, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val search = Button(this).apply {
            text = "بحث"
            setOnClickListener { doSearch() }
        }
        val reindex = Button(this).apply {
            text = "إعادة الفهرسة"
            setOnClickListener { indexFiles() }
        }
        row.addView(search, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(reindex, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        val sd = Button(this).apply {
            text = "اختيار بطاقة SD"
            setOnClickListener { chooseSdCard() }
        }
        root.addView(sd)

        progress = ProgressBar(this).apply { visibility = ProgressBar.GONE }
        root.addView(progress)

        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 10, 0, 10)
        }
        root.addView(status)

        val scroll = ScrollView(this)
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun chooseSdCard() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        startActivityForResult(intent, 900)
    }

    @Deprecated("Use Activity Result API in a future revision")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 900 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            getSharedPreferences(sdPrefs, MODE_PRIVATE).edit().putString(sdUriKey, uri.toString()).apply()
            indexFiles()
        }
    }

    private fun indexFiles() {
        if (!hasStoragePermission()) {
            requestStoragePermission()
            return
        }

        progress.visibility = ProgressBar.VISIBLE
        status.text = "جارٍ فهرسة الملفات..."
        thread {
            val found = ArrayList<FileItem>()
            scan(Environment.getExternalStorageDirectory(), found)

            val sd = getSharedPreferences(sdPrefs, MODE_PRIVATE).getString(sdUriKey, null)
            if (!sd.isNullOrBlank()) {
                try {
                    val root = DocumentFile.fromTreeUri(this, Uri.parse(sd))
                    if (root != null) scanDocumentTree(root, found)
                } catch (_: Exception) {}
            }

            synchronized(index) {
                index.clear()
                index.addAll(found)
            }
            runOnUiThread {
                progress.visibility = ProgressBar.GONE
                val sdText = if (sd.isNullOrBlank()) " | بطاقة SD: غير مضافة" else " | بطاقة SD: مضافة"
                status.text = "تمت فهرسة ${decimal.format(index.size)} ملف$sdText."
            }
        }
    }

    private fun scan(dir: File, out: MutableList<FileItem>) {
        if (!dir.exists() || !dir.canRead()) return
        val children = try { dir.listFiles() } catch (_: Exception) { null } ?: return
        for (f in children) {
            if (f.isDirectory) {
                // Avoid the Android/data and Android/obb trees which can cause access errors.
                if (f.name != "Android") scan(f, out)
            } else if (f.isFile) {
                out.add(FileItem(f.name, f.absolutePath, 0, file = f))
            }
        }
    }

    private fun scanDocumentTree(dir: DocumentFile, out: MutableList<FileItem>) {
        if (!dir.isDirectory) return
        val children = try { dir.listFiles() } catch (_: Exception) { return }
        for (f in children) {
            if (f.isDirectory) {
                scanDocumentTree(f, out)
            } else if (f.isFile) {
                out.add(FileItem(f.name ?: "", f.uri.toString(), 0, document = f))
            }
        }
    }

    private fun doSearch() {
        val q = normalize(searchBox.text.toString())
        results.removeAllViews()
        if (q.isBlank()) {
            status.text = "اكتب جزءًا أو عدة أجزاء من اسم الملف."
            return
        }

        val queryParts = q.split(" ").filter { it.isNotBlank() }
        val matches = synchronized(index) {
            index.mapNotNull { item ->
                val score = matchScore(normalize(item.displayName), queryParts)
                if (score > 0) item.copy(score = score) else null
            }.sortedByDescending { it.score }.take(300)
        }

        status.text = "النتائج: ${matches.size}"
        if (matches.isEmpty()) {
            results.addView(TextView(this).apply {
                text = "لم يتم العثور على ملفات مطابقة."
                textSize = 17f
                setPadding(0, 20, 0, 20)
            })
            return
        }
        matches.forEach { addResult(it) }
    }

    private fun matchScore(name: String, parts: List<String>): Int {
        var total = 0
        for (part in parts) {
            val exact = name.indexOf(part)
            if (exact >= 0) {
                total += 1000 + part.length * 20
                continue
            }
            var pos = 0
            var matched = 0
            for (ch in part) {
                val p = name.indexOf(ch, pos)
                if (p >= 0) {
                    matched++
                    pos = p + 1
                }
            }
            if (matched != part.length) return 0
            total += 200 + matched * 10
        }
        total += parts.count { name.contains(it) } * 100
        return total
    }

    private fun normalize(s: String): String {
        return s.lowercase(Locale.ROOT)
            .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ٱ', 'ا')
            .replace('ى', 'ي').replace('ة', 'ه')
            .replace(Regex("[_\\-.]+"), " ")
            .replace(Regex("\\s+"), " ").trim()
    }

    private fun addResult(item: FileItem) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }
        box.addView(TextView(this).apply { text = item.displayName; textSize = 17f })
        box.addView(TextView(this).apply { text = item.path; textSize = 12f })
        box.addView(Button(this).apply {
            text = "فتح"
            setOnClickListener { openFile(item) }
        })
        results.addView(box)
    }

    private fun openFile(item: FileItem) {
        if (item.file != null) {
            val uri = try {
                androidx.core.content.FileProvider.getUriForFile(
                    this, "$packageName.fileprovider", item.file
                )
            } catch (_: Exception) {
                null
            }
            if (uri != null) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    startActivity(intent)
                    return
                } catch (_: Exception) {}
            }
        }

        if (item.document != null) {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = item.document.uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(intent)
                return
            } catch (_: Exception) {}
        }

        Toast.makeText(this, "لا يوجد تطبيق مناسب لفتح هذا الملف.", Toast.LENGTH_SHORT).show()
    }
}
